package com.example.web;

import lombok.Data;

@Data
public class TaskRequest {
    private String title;
}
